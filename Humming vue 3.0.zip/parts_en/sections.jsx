/* HFO Explainer — preserved sections (Hero, WaveformCompare, Metaphor,
   Indications, HowToStart, AdjustmentMatrix, Mistakes, DeviceAnatomy, CheatSheet)
   English edition. */

const { useState, useEffect, useRef, useMemo } = React;

/* ---------- Shared ---------- */
function SectionLabel({ n, label }) {
  return (
    <div className="sec-label">
      <span className="sec-num">{n}</span>
      <span className="sec-eyebrow">{label}</span>
    </div>
  );
}
function Tag({ children, color = "teal" }) {
  return <span className={`tag tag-${color}`}>{children}</span>;
}

/* ---------- 1. HERO ---------- */
function Hero() {
  return (
    <section className="hero" data-screen-label="01 Hero">
      <div className="hero-grid"></div>
      <div className="hero-inner">
        <div className="brand-row">
          <img src={(typeof window !== 'undefined' && window.__resources && window.__resources.logoWordmark) || "assets/logo-wordmark.svg"} alt="Swanston-Med" className="logo" />
          <span className="brand-sep">·</span>
          <span className="brand-product">HUMMING VUE · HFO</span>
        </div>

        <div className="eyebrow hero-eyebrow">Working guide · for clinicians</div>
        <h1 className="hero-title">
          A hummingbird beats its wings<br />
          <span className="hero-title-accent">80 times a second.</span><br />
          That's how <span className="hero-title-accent">HFO</span> breathes.
        </h1>

        <p className="hero-sub">
          High-frequency oscillatory ventilation isn't "normal ventilation, only faster."
          It's a completely different way to make the lungs work. Tiny, very rapid
          oscillations instead of big breaths. Here are the fundamentals in 15 minutes, plus
          a simulator where you can turn the dials and watch what changes.
        </p>

        <div className="hero-rule"></div>

        <div className="hero-meta">
          <div className="hero-meta-item">
            <div className="hero-meta-label">Frequency</div>
            <div className="hero-meta-value num">5–15 <span className="unit">Hz</span></div>
          </div>
          <div className="hero-meta-item">
            <div className="hero-meta-label">Stroke Volume</div>
            <div className="hero-meta-value num">0.2 <span className="unit">mL step</span></div>
          </div>
          <div className="hero-meta-item">
            <div className="hero-meta-label">Piston</div>
            <div className="hero-meta-value num">13 <span className="unit">µm precision</span></div>
          </div>
          <div className="hero-meta-item">
            <div className="hero-meta-label">DCO₂</div>
            <div className="hero-meta-value num">V<span className="unit">hfo</span>² × f</div>
          </div>
        </div>

        <div className="hero-scroll">
          <span>read on</span>
          <span className="arrow">↓</span>
        </div>
      </div>
    </section>
  );
}

/* ---------- 2. CONVENTIONAL vs HFO ---------- */
function WaveformCompare() {
  const [running, setRunning] = useState(true);
  const cvRef = useRef(null);
  const hfRef = useRef(null);

  useEffect(() => {
    let raf;
    let t0 = performance.now();
    function draw() {
      const cv = cvRef.current;
      const hf = hfRef.current;
      if (!cv || !hf) return;
      const t = (performance.now() - t0) / 1000;
      [cv, hf].forEach((canvas, idx) => {
        const ctx = canvas.getContext("2d");
        const W = canvas.width, H = canvas.height;
        ctx.clearRect(0, 0, W, H);
        ctx.strokeStyle = "#E2E8F0";
        ctx.lineWidth = 1;
        ctx.setLineDash([4, 4]);
        ctx.beginPath(); ctx.moveTo(0, H/2); ctx.lineTo(W, H/2); ctx.stroke();
        ctx.setLineDash([]);
        ctx.lineWidth = 2.5;
        ctx.strokeStyle = idx === 0 ? "#1E3A5F" : "#0D9488";
        ctx.beginPath();
        for (let x = 0; x <= W; x++) {
          const phase = (x / W) * Math.PI * 2;
          let y;
          if (idx === 0) {
            const v = Math.sin(phase * 0.6 - t * 1.6);
            const breath = Math.sign(v) * Math.pow(Math.abs(v), 0.7);
            y = H/2 - breath * (H * 0.36);
          } else {
            const v = Math.sin(phase * 18 - t * 14);
            y = H/2 - v * (H * 0.12);
          }
          if (x === 0) ctx.moveTo(x, y); else ctx.lineTo(x, y);
        }
        ctx.stroke();
        if (idx === 1) {
          ctx.strokeStyle = "#F59E0B";
          ctx.lineWidth = 1.5;
          ctx.setLineDash([6, 4]);
          ctx.beginPath(); ctx.moveTo(0, H/2); ctx.lineTo(W, H/2); ctx.stroke();
          ctx.setLineDash([]);
          ctx.fillStyle = "#92400E";
          ctx.font = "600 11px 'Inter Tight', sans-serif";
          ctx.fillText("MAP — constant mean airway pressure", 10, H/2 - 8);
        }
      });
      if (running) raf = requestAnimationFrame(draw);
    }
    if (running) raf = requestAnimationFrame(draw);
    return () => cancelAnimationFrame(raf);
  }, [running]);

  return (
    <section className="block" data-screen-label="02 Conventional vs HFO">
      <SectionLabel n="01" label="Concept · Conventional vs HFO" />
      <h2 className="block-title">
        Conventional ventilation is <span className="muted">"breathe in, breathe out."</span><br />
        HFO is <span className="accent">"shimmering air."</span>
      </h2>

      <div className="wave-grid">
        <div className="wave-card">
          <div className="wave-head">
            <Tag color="navy">Conventional · CMV</Tag>
            <div className="wave-stat">
              <span className="num">25</span>
              <span className="wave-stat-unit">breaths/min</span>
            </div>
          </div>
          <canvas ref={cvRef} width="600" height="200" className="wave-canvas"></canvas>
          <ul className="wave-list">
            <li>Big breaths, the usual way — in and back out</li>
            <li>Alveoli <b>stretch open and collapse</b> on every cycle</li>
            <li>Tidal volume <span className="num">6–8 mL/kg</span></li>
            <li className="risk">Risk of baro/volutrauma in fragile lungs</li>
          </ul>
        </div>

        <div className="wave-card wave-card-hfo">
          <div className="wave-head">
            <Tag color="teal">HFO · Humming Vue</Tag>
            <div className="wave-stat">
              <span className="num">600+</span>
              <span className="wave-stat-unit">per minute</span>
            </div>
          </div>
          <canvas ref={hfRef} width="600" height="200" className="wave-canvas"></canvas>
          <ul className="wave-list">
            <li>Lungs are <b>always open</b> on a constant MAP</li>
            <li>The piston pushes a tiny <b>Stroke Volume (SV)</b> that produces <b>V<sub>hfo</sub></b> — the volume actually delivered</li>
            <li>V<sub>hfo</sub> <span className="num">1.2–2 mL/kg</span> — smaller than dead space</li>
            <li className="safe">The lung doesn't "move" — it "hums"</li>
          </ul>
        </div>
      </div>

      <div className="wave-controls">
        <button className="btn btn-ghost" onClick={() => setRunning(r => !r)}>
          {running ? "⏸ Pause" : "▶ Play"}
        </button>
        <span className="wave-controls-hint">Real-time animation</span>
      </div>
    </section>
  );
}

/* ---------- 3. METAPHOR ---------- */
function Hummingbird() {
  return (
    <svg viewBox="0 0 480 480" className="hb-svg">
      <circle cx="240" cy="240" r="200" fill="none" stroke="#0D9488" strokeWidth="1.5" strokeDasharray="2 6" opacity="0.35"/>
      <circle cx="240" cy="240" r="160" fill="none" stroke="#0D9488" strokeWidth="1" strokeDasharray="1 5" opacity="0.25"/>
      <g className="hb-wing-blur">
        <ellipse cx="190" cy="220" rx="110" ry="22" fill="#0D9488" opacity="0.10"/>
        <ellipse cx="190" cy="220" rx="100" ry="14" fill="#0D9488" opacity="0.18"/>
      </g>
      <g className="hb-wing">
        <path d="M 230 220 Q 130 180 90 230 Q 130 235 230 230 Z" fill="#0D9488" opacity="0.55"/>
      </g>
      <ellipse cx="270" cy="240" rx="55" ry="28" fill="#1E3A5F"/>
      <circle cx="320" cy="225" r="22" fill="#0A1628"/>
      <circle cx="328" cy="220" r="3" fill="#fff"/>
      <path d="M 340 225 L 395 225" stroke="#0A1628" strokeWidth="3.5" strokeLinecap="round"/>
      <path d="M 215 240 L 175 250 L 215 252 L 180 264 L 218 256 Z" fill="#0A1628"/>
      <ellipse cx="305" cy="245" rx="12" ry="7" fill="#F59E0B"/>
      <g className="hb-pulse">
        <circle cx="410" cy="215" r="3" fill="#0D9488"/>
        <circle cx="425" cy="225" r="2" fill="#0D9488" opacity="0.6"/>
        <circle cx="438" cy="220" r="1.5" fill="#0D9488" opacity="0.3"/>
      </g>
      <text x="60" y="380" fontFamily="Inter Tight" fontWeight="700" fontSize="14" fill="#0A1628" letterSpacing="2">
        50–80 WINGBEATS PER SECOND
      </text>
      <text x="60" y="400" fontFamily="JetBrains Mono" fontSize="12" fill="#64748B">
        ≈ the HFO oscillation rate
      </text>
    </svg>
  );
}

function Metaphor() {
  return (
    <section className="block block-tinted" data-screen-label="03 Metaphor">
      <SectionLabel n="02" label="Metaphor · Explain it like a child would get it" />
      <h2 className="block-title">
        Picture a <span className="accent">hummingbird</span>.
      </h2>

      <div className="metaphor-grid">
        <div className="metaphor-vis">
          <Hummingbird />
        </div>
        <div className="metaphor-copy">
          <p className="lead">
            When a hummingbird hovers, it beats its wings <b>50–80 times a second</b>.
            The wings barely move up and down — they just <b>shimmer</b>.
            But that's enough to stay airborne.
          </p>

          <div className="metaphor-points">
            <div className="mp">
              <div className="mp-icon">🪽</div>
              <div>
                <div className="mp-title">Small movements, very frequent</div>
                <div className="mp-body">That's HFO: instead of big breaths — tiny oscillations, up to <span className="num">15 times a second</span>.</div>
              </div>
            </div>
            <div className="mp">
              <div className="mp-icon">🎈</div>
              <div>
                <div className="mp-title">A balloon kept permanently inflated</div>
                <div className="mp-body">Alveoli are micro-balloons. On conventional ventilation we inflate and deflate them each time. On HFO we <b>keep them inflated</b> and gently shake them.</div>
              </div>
            </div>
            <div className="mp">
              <div className="mp-icon">🎵</div>
              <div>
                <div className="mp-title">Sound inside an organ pipe</div>
                <div className="mp-body">Air in the tube vibrates like sound. Gases (O₂, CO₂) <b>mix through vibration</b>, not through "arrive-and-leave."</div>
              </div>
            </div>
            <div className="mp">
              <div className="mp-icon">👶</div>
              <div>
                <div className="mp-title">Why it matters for the tiniest patients</div>
                <div className="mp-body">A newborn's lungs are like a thin film. Every big stretch is an injury. HFO <b>doesn't stretch</b> — it rocks.</div>
              </div>
            </div>
          </div>

          <div className="quote">
            <div className="quote-mark">“</div>
            <div>
              <div className="quote-text">
                A lung on HFO doesn't <b>breathe</b> — it <b>hums</b>. That's where the device gets its name — <b>Humming</b>.
              </div>
              <div className="quote-attr">— a simple rule to remember</div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}

/* ---------- 4. INDICATIONS ---------- */
const INDICATIONS = [
  { code: "RDS", ru: "Respiratory distress syndrome", desc: "Preterm. Immature lungs, little surfactant. HFO gives the alveoli a \"rest.\"", tag: "Preterm", color: "blue", icon: "👶" },
  { code: "MAS", ru: "Meconium aspiration syndrome", desc: "Term infants. Meconium blocks small airways unevenly. HFO oscillations \"pump\" gas past the plugs.", tag: "Term", color: "amber", icon: "🫁" },
  { code: "PPHN", ru: "Persistent pulmonary hypertension", desc: "Paired with iNO. HFO opens the capillary bed via a stable MAP.", tag: "+ iNO", color: "purple", icon: "💧" },
  { code: "Air leak", ru: "Pneumothorax / interstitial emphysema", desc: "Air leak. Small oscillations don't \"inflate\" the hole — it gets a chance to close.", tag: "Leak", color: "red", icon: "💨" },
  { code: "CDH", ru: "Congenital diaphragmatic hernia", desc: "Lung hypoplasia. The low volumes of HFO protect the little tissue there is.", tag: "Surgical", color: "cyan", icon: "⚕️" },
  { code: "Rescue", ru: "After CMV fails", desc: "When conventional ventilation needs FiO₂ > 60% and MAP > 12 — switch to HFO before injury sets in.", tag: "Rescue", color: "teal", icon: "🆘" },
];

function Indications() {
  return (
    <section className="block" data-screen-label="04 Indications">
      <SectionLabel n="04" label="Indications · When to use it" />
      <h2 className="block-title">
        Six situations where HFO is the <span className="accent">right choice.</span>
      </h2>
      <p className="block-sub">
        HFO isn't "the next step after conventional ventilation." It's a <b>different tool</b> for specific jobs.
        Learn these six — that covers 95% of real NICU cases.
      </p>

      <div className="ind-grid">
        {INDICATIONS.map(i => (
          <div key={i.code} className={`ind-card ind-${i.color}`}>
            <div className="ind-head">
              <div className="ind-icon">{i.icon}</div>
              <div>
                <div className="ind-code">{i.code}</div>
                <div className="ind-ru">{i.ru}</div>
              </div>
              <div className="ind-tag">{i.tag}</div>
            </div>
            <p className="ind-desc">{i.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------- 6. HOW TO START ---------- */
const STEPS = [
  { n: 1, title: "Optimize MAP", short: "Open the lungs",
    body: "Set MAP 1–2 cmH₂O above what it was on CMV. Raise it gradually by 1 cmH₂O every 2–3 minutes until SpO₂ improves. Then drop it by 1 cm at a time until SpO₂ starts to fall — that's the \"opening point.\" Set MAP 2 cm above it.",
    pitfall: "Too much MAP → overdistension → impaired perfusion → desaturation. Too little → atelectasis.",
    visual: "lungs-open" },
  { n: 2, title: "Set frequency (f)", short: "By age",
    body: "Newborns: 10–15 Hz. Under 1 year: 8–10 Hz. Older: 6–8 Hz. Adults: 3–5 Hz. The smaller the patient, the higher the frequency.",
    pitfall: "Change frequency rarely. It's the \"coarse setting\" — it keeps the system in tune.",
    visual: "freq" },
  { n: 3, title: "Dial in Stroke Volume (SV)", short: "Main control",
    body: "On Humming Vue you turn SV (the piston's stroke volume), not amplitude. Start at 2 mL/kg (or 1.2–1.4 mL/kg with hypocapnia / spontaneous breathing). Step is 0.2 mL. Target: visible chest wiggle down to the navel. After 20–30 min — blood gas, adjust by 0.5–1 mL.",
    pitfall: "Amplitude (ΔP) is a consequence of SV, not the thing you turn.",
    visual: "shake" },
  { n: 4, title: "FiO₂ and verification", short: "Less is better",
    body: "Start FiO₂ at 90–100%, then drop by 5%. The main oxygenation tool is a properly chosen MAP combined with SV. Well-recruited lungs = less FiO₂. Target: SpO₂ 90–95% at FiO₂ < 60%. After 30 minutes — chest X-ray (8–9 ribs) and blood gas.",
    pitfall: "FiO₂ > 60% for more than 6 hours — toxic lung injury.",
    visual: "xray" },
];

function StepVisual({ kind }) {
  if (kind === "lungs-open") return (
    <svg viewBox="0 0 200 200" className="sv-svg">
      <ellipse cx="75" cy="100" rx="35" ry="55" fill="#0D9488" opacity="0.18"/>
      <ellipse cx="125" cy="100" rx="35" ry="55" fill="#0D9488" opacity="0.18"/>
      <path d="M 75 50 Q 85 100 75 150" stroke="#0D9488" strokeWidth="2" fill="none"/>
      <path d="M 125 50 Q 115 100 125 150" stroke="#0D9488" strokeWidth="2" fill="none"/>
      <line x1="100" y1="20" x2="100" y2="50" stroke="#0A1628" strokeWidth="3"/>
      <line x1="100" y1="50" x2="75" y2="60" stroke="#0A1628" strokeWidth="2"/>
      <line x1="100" y1="50" x2="125" y2="60" stroke="#0A1628" strokeWidth="2"/>
      <text x="100" y="190" textAnchor="middle" fontFamily="Inter Tight" fontWeight="700" fontSize="11" fill="#0A1628">OPEN</text>
    </svg>
  );
  if (kind === "freq") return (
    <svg viewBox="0 0 200 200" className="sv-svg">
      <text x="100" y="60" textAnchor="middle" fontFamily="Inter Tight" fontWeight="800" fontSize="42" fill="#1E3A5F">10</text>
      <text x="100" y="90" textAnchor="middle" fontFamily="JetBrains Mono" fontSize="14" fill="#64748B">Hz</text>
      <g stroke="#0D9488" strokeWidth="2" fill="none">
        <path d="M 30 130 Q 40 115 50 130 T 70 130 T 90 130 T 110 130 T 130 130 T 150 130 T 170 130"/>
      </g>
      <text x="100" y="180" textAnchor="middle" fontFamily="Inter Tight" fontWeight="700" fontSize="11" fill="#0A1628">NEWBORN</text>
    </svg>
  );
  if (kind === "shake") return (
    <svg viewBox="0 0 200 200" className="sv-svg">
      <rect x="50" y="40" width="100" height="120" rx="20" fill="#F59E0B" opacity="0.15" stroke="#F59E0B" strokeWidth="2"/>
      <line x1="50" y1="80" x2="150" y2="80" stroke="#F59E0B" strokeWidth="1" strokeDasharray="3 3"/>
      <line x1="50" y1="120" x2="150" y2="120" stroke="#F59E0B" strokeWidth="1" strokeDasharray="3 3"/>
      <circle cx="100" cy="100" r="4" fill="#F59E0B"/>
      <text x="100" y="180" textAnchor="middle" fontFamily="Inter Tight" fontWeight="700" fontSize="11" fill="#0A1628">TO THE NAVEL</text>
    </svg>
  );
  return (
    <svg viewBox="0 0 200 200" className="sv-svg">
      <rect x="40" y="30" width="120" height="140" rx="6" fill="#1E3A5F" opacity="0.12" stroke="#1E3A5F" strokeWidth="1.5"/>
      <g stroke="#1E3A5F" strokeWidth="1" opacity="0.5">
        {[55,70,85,100,115,130,145].map(y => (
          <React.Fragment key={y}>
            <line x1="55" y1={y} x2="95" y2={y}/>
            <line x1="105" y1={y} x2="145" y2={y}/>
          </React.Fragment>
        ))}
      </g>
      <text x="100" y="190" textAnchor="middle" fontFamily="Inter Tight" fontWeight="700" fontSize="11" fill="#0A1628">8–9 RIBS</text>
    </svg>
  );
}

function HowToStart() {
  const [active, setActive] = useState(1);
  const step = STEPS.find(s => s.n === active);
  return (
    <section className="block block-tinted" data-screen-label="06 Start">
      <SectionLabel n="10" label="Start · The first 30 minutes" />
      <h2 className="block-title">
        How to <span className="accent">start</span> a patient on HFO.
      </h2>
      <p className="block-sub">
        Four steps, in order. Don't skip. Click a step to expand the detail.
      </p>

      <div className="steps-tabs">
        {STEPS.map(s => (
          <button key={s.n}
            className={`step-tab ${active === s.n ? "active" : ""}`}
            onClick={() => setActive(s.n)}>
            <div className="step-tab-num">{String(s.n).padStart(2, "0")}</div>
            <div className="step-tab-body">
              <div className="step-tab-title">{s.title}</div>
              <div className="step-tab-short">{s.short}</div>
            </div>
          </button>
        ))}
      </div>

      <div className="step-detail">
        <div className="step-detail-num">{String(step.n).padStart(2, "0")}</div>
        <div className="step-detail-body">
          <h3 className="step-detail-title">{step.title}</h3>
          <p className="step-detail-text">{step.body}</p>
          <div className="step-pitfall">
            <span className="step-pitfall-label">⚠ Catch</span>
            <span>{step.pitfall}</span>
          </div>
        </div>
        <div className="step-detail-vis">
          <StepVisual kind={step.visual} />
        </div>
      </div>
    </section>
  );
}

/* ---------- 7. ADJUSTMENT MATRIX ---------- */
const ADJUSTMENTS = [
  { problem: "SpO₂ low", cause: "Lungs under-recruited or not enough O₂", fix: "↑ MAP by 1–2 cmH₂O · then ↑ FiO₂", which: "oxygenation" },
  { problem: "SpO₂ high, FiO₂ high", cause: "Ready to wean", fix: "↓ FiO₂ by 5% · then ↓ MAP by 1 cm", which: "oxygenation" },
  { problem: "pCO₂ high (hypercapnia)", cause: "Weak mixing — low V_hfo, low DCO₂", fix: "↑ SV by 0.5–1 mL · if maxed, ↓ f by 1 Hz", which: "ventilation" },
  { problem: "pCO₂ low (hypocapnia)", cause: "Over-ventilation · risk of alkalosis", fix: "↓ SV by 0.5–1 mL (aim for V_hfo 1.2–1.4 mL/kg)", which: "ventilation" },
  { problem: "No wiggle, chest not vibrating, DCO₂ → 0", cause: "Disconnection or blocked tube (ETT)", fix: "Suction · check ETT · watch ΔA and V_hfo on screen", which: "alarm" },
  { problem: "Sudden SpO₂ drop", cause: "Pneumothorax? Overdistension from high MAP?", fix: "Auscultate · urgent X-ray · check measured MAP", which: "alarm" },
  { problem: "ΔA rising, V_hfo and DCO₂ crashed", cause: "ETT blocked", fix: "Suction immediately", which: "alarm" },
  { problem: "ΔA rising, V_hfo dipped slightly, DCO₂ critically low", cause: "Poor airway compliance", fix: "Recruitment maneuver, ↑ MAP · optimize SV", which: "ventilation" },
];

function AdjustmentMatrix() {
  const [filter, setFilter] = useState("all");
  const filtered = filter === "all" ? ADJUSTMENTS : ADJUSTMENTS.filter(a => a.which === filter);
  return (
    <section className="block" data-screen-label="07 Adjust">
      <SectionLabel n="11" label="Correction · What to do if…" />
      <h2 className="block-title">
        The blood gas spoke — <span className="accent">what do I turn?</span>
      </h2>
      <p className="block-sub">
        A simple cheat table. First decide the problem — is it oxygenation or ventilation? Then act.
      </p>
      <div className="filter-row">
        <button className={`filter-btn ${filter === "all" ? "active" : ""}`} onClick={() => setFilter("all")}>All</button>
        <button className={`filter-btn ${filter === "oxygenation" ? "active" : ""}`} onClick={() => setFilter("oxygenation")}>Oxygenation · SpO₂</button>
        <button className={`filter-btn ${filter === "ventilation" ? "active" : ""}`} onClick={() => setFilter("ventilation")}>Ventilation · CO₂</button>
        <button className={`filter-btn ${filter === "alarm" ? "active" : ""}`} onClick={() => setFilter("alarm")}>Alarm</button>
      </div>
      <table className="adj-table">
        <thead>
          <tr><th>Problem</th><th>Cause</th><th>What to do</th><th></th></tr>
        </thead>
        <tbody>
          {filtered.map((a, i) => (
            <tr key={i} className={`adj-row adj-${a.which}`}>
              <td className="adj-problem">{a.problem}</td>
              <td className="adj-cause">{a.cause}</td>
              <td className="adj-fix">{a.fix}</td>
              <td><span className={`adj-tag adj-tag-${a.which}`}>{a.which}</span></td>
            </tr>
          ))}
        </tbody>
      </table>
    </section>
  );
}

/* ---------- 8. MISTAKES ---------- */
const MISTAKES = [
  { do: "Set MAP by the \"opening point\" — min to max, then back down", dont: "Copy the MAP from CMV — it'll be too low", why: "On HFO you must keep the lungs open continuously. Too low a MAP → poor compliance. Too high → overdistension → impaired perfusion → desaturation." },
  { do: "Change one thing at a time", dont: "Turn MAP, SV and f all at once", why: "You won't know which change helped and which one hurt." },
  { do: "Watch the chest and V_hfo / DCO₂", dont: "Go by numbers alone or by eye alone", why: "Visible wiggle down to the navel + rising DCO₂ are the best signs the device is working." },
  { do: "Blood gas at 20–30 minutes", dont: "At 5 minutes or after an hour", why: "Too early — it hasn't equilibrated. Too late — you'll miss decompensation." },
  { do: "Sedation, and sometimes paralysis", dont: "Fight the patient's active breathing", why: "Spontaneous breaths on HFO disrupt the whole physiology of the method." },
  { do: "Drop FiO₂ first when weaning", dont: "Slash MAP abruptly", why: "A sudden MAP drop → alveolar collapse → start all over again." },
];

function Mistakes() {
  return (
    <section className="block block-tinted" data-screen-label="08 Mistakes">
      <SectionLabel n="12" label="Mistakes · DO & DON'T" />
      <h2 className="block-title">
        Six things <span className="accent">everyone trips over.</span>
      </h2>
      <div className="mistakes-grid">
        {MISTAKES.map((m, i) => (
          <div key={i} className="mistake-card">
            <div className="mistake-num num">{String(i + 1).padStart(2, "0")}</div>
            <div className="mistake-pair">
              <div className="mistake-do">
                <div className="mistake-label mistake-label-do">✓ Do</div>
                <div className="mistake-text">{m.do}</div>
              </div>
              <div className="mistake-dont">
                <div className="mistake-label mistake-label-dont">✗ Don't</div>
                <div className="mistake-text">{m.dont}</div>
              </div>
            </div>
            <div className="mistake-why">
              <span className="mistake-why-label">Why</span>
              {m.why}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}

/* ---------- 9. DEVICE ANATOMY ---------- */
function DeviceSvg({ parts, hover, setHover }) {
  return (
    <svg viewBox="0 0 600 500" className="device-svg">
      <rect x="120" y="60" width="360" height="380" rx="14" fill="#F8FAFC" stroke="#CBD5E1" strokeWidth="2"/>
      <rect x="120" y="60" width="360" height="40" rx="14" fill="#1E3A5F"/>
      <text x="140" y="86" fontFamily="Inter Tight" fontWeight="800" fontSize="14" fill="#fff" letterSpacing="2">HUMMING VUE</text>
      <circle cx="460" cy="80" r="5" fill="#F59E0B"/>
      <rect x="150" y="120" width="300" height="150" rx="6" fill="#0A1628" stroke="#0D9488" strokeWidth="1.5"/>
      <text x="165" y="140" fontFamily="JetBrains Mono" fontSize="9" fill="#0D9488">HFO · ACTIVE</text>
      <text x="165" y="170" fontFamily="JetBrains Mono" fontSize="22" fontWeight="600" fill="#14B8A6">12.0</text>
      <text x="165" y="184" fontFamily="JetBrains Mono" fontSize="8" fill="#64748B">MAP cmH₂O</text>
      <text x="245" y="170" fontFamily="JetBrains Mono" fontSize="22" fontWeight="600" fill="#F59E0B">6.0</text>
      <text x="245" y="184" fontFamily="JetBrains Mono" fontSize="8" fill="#64748B">SV mL</text>
      <text x="320" y="170" fontFamily="JetBrains Mono" fontSize="22" fontWeight="600" fill="#fff">10.0</text>
      <text x="320" y="184" fontFamily="JetBrains Mono" fontSize="8" fill="#64748B">f Hz</text>
      <text x="395" y="170" fontFamily="JetBrains Mono" fontSize="22" fontWeight="600" fill="#3B82F6">40</text>
      <text x="395" y="184" fontFamily="JetBrains Mono" fontSize="8" fill="#64748B">FiO₂ %</text>
      <text x="165" y="248" fontFamily="JetBrains Mono" fontSize="10" fill="#94A3B8">DCO₂ 360 · ΔA 22 · V_hfo 5.9 mL</text>
      <path d="M 165 230 Q 175 220 185 230 T 205 230 T 225 230 T 245 230 T 265 230 T 285 230 T 305 230 T 325 230 T 345 230 T 365 230 T 385 230 T 405 230 T 425 230" stroke="#14B8A6" strokeWidth="1.5" fill="none"/>
      <g>
        <circle cx="180" cy="320" r="22" fill="#0A1628" stroke="#0D9488" strokeWidth="2"/>
        <line x1="180" y1="320" x2="180" y2="306" stroke="#0D9488" strokeWidth="2"/>
        <text x="180" y="358" textAnchor="middle" fontFamily="Inter Tight" fontSize="9" fontWeight="700" fill="#0A1628">MAP</text>
        <circle cx="250" cy="320" r="22" fill="#0A1628" stroke="#F59E0B" strokeWidth="2"/>
        <line x1="250" y1="320" x2="262" y2="312" stroke="#F59E0B" strokeWidth="2"/>
        <text x="250" y="358" textAnchor="middle" fontFamily="Inter Tight" fontSize="9" fontWeight="700" fill="#0A1628">SV</text>
        <circle cx="320" cy="320" r="22" fill="#0A1628" stroke="#fff" strokeWidth="2"/>
        <line x1="320" y1="320" x2="320" y2="334" stroke="#fff" strokeWidth="2"/>
        <text x="320" y="358" textAnchor="middle" fontFamily="Inter Tight" fontSize="9" fontWeight="700" fill="#0A1628">f</text>
        <circle cx="390" cy="320" r="22" fill="#0A1628" stroke="#3B82F6" strokeWidth="2"/>
        <line x1="390" y1="320" x2="378" y2="312" stroke="#3B82F6" strokeWidth="2"/>
        <text x="390" y="358" textAnchor="middle" fontFamily="Inter Tight" fontSize="9" fontWeight="700" fill="#0A1628">FiO₂</text>
      </g>
      <path d="M 480 240 Q 540 240 540 320 Q 540 400 480 400" stroke="#0D9488" strokeWidth="3" fill="none" strokeLinecap="round"/>
      <circle cx="480" cy="240" r="6" fill="#0D9488"/>
      <circle cx="480" cy="400" r="6" fill="#0D9488"/>
      {parts.map((p, i) => {
        const cx = (p.x / 100) * 600;
        const cy = (p.y / 100) * 500;
        const isActive = hover === p.id;
        return (
          <g key={p.id}
             onMouseEnter={() => setHover(p.id)}
             onMouseLeave={() => setHover(null)}
             style={{ cursor: "pointer" }}>
            <circle cx={cx} cy={cy} r="22" fill="#0D9488" opacity={isActive ? 0.25 : 0}/>
            <circle cx={cx} cy={cy} r="14" fill="#0D9488" opacity={isActive ? 0.5 : 0}/>
            <circle cx={cx} cy={cy} r="9" fill="#F59E0B" stroke="#fff" strokeWidth="2"/>
            <text x={cx} y={cy + 4} textAnchor="middle" fontFamily="Inter Tight" fontSize="11" fontWeight="800" fill="#fff">{i + 1}</text>
          </g>
        );
      })}
    </svg>
  );
}

function DeviceAnatomy() {
  const [hover, setHover] = useState(null);
  const parts = [
    { id: "screen", label: "Screen · 4 settings + 4 automatic readings", x: 50, y: 18, desc: "Large touchscreen. On the right — 4 adjustable parameters (SV, MAP, f, FiO₂). On the left — 4 auto-readings: ΔA (amplitude), measured MAP, V_hfo, DCO₂. ΔP is not set — it's a consequence of SV." },
    { id: "piston", label: "13 µm piston · the heart of the device", x: 25, y: 50, desc: "A precision piston accurate to 13 micrometers. 90% of components — Japan. It produces an exact Stroke Volume (SV) — the stroke that forms V_hfo. Volume-based principle → laminar flow → precise delivery regardless of compliance." },
    { id: "circuit", label: "Breathing circuit", x: 75, y: 60, desc: "Heated humidifier + a dedicated HFO circuit. Not to be confused with a conventional ventilator tube." },
    { id: "controls", label: "Controls for the 4 parameters", x: 50, y: 75, desc: "MAP · SV · f · FiO₂ — the four main dials. SV (Stroke Volume) is the primary ventilation control, resolution 0.2 mL. Amplitude ΔA is displayed as a consequence — it isn't set directly." },
    { id: "alarm", label: "Audible and visual alarm", x: 85, y: 18, desc: "Distinguishes critical (red) from informational (amber) alarms. DCO₂ → 0 plus a sharp ΔA rise — critical alarm: possible ETT obstruction." },
  ];
  const active = hover ? parts.find(p => p.id === hover) : null;

  return (
    <section className="block block-dark" data-screen-label="09 Device">
      <SectionLabel n="13" label="Device · Humming Vue" />
      <h2 className="block-title block-title-dark">
        The <span className="accent">Humming Vue</span> itself.
      </h2>
      <p className="block-sub block-sub-dark">
        Hover over the numbers to learn what's what.
      </p>

      <div className="device-stage">
        <div className="device-illustration">
          <DeviceSvg parts={parts} hover={hover} setHover={setHover} />
        </div>

        <div className="device-info">
          {active ? (
            <div className="device-info-active">
              <div className="device-info-label eyebrow">{active.id.toUpperCase()}</div>
              <div className="device-info-title">{active.label}</div>
              <div className="device-info-desc">{active.desc}</div>
            </div>
          ) : (
            <div className="device-info-default">
              <div className="device-info-label eyebrow">Technical spec</div>
              <ul className="spec-list">
                <li><span className="spec-k">Drive type</span><span className="spec-v num">Piston, 13 µm</span></li>
                <li><span className="spec-k">Origin</span><span className="spec-v num">90% Japan</span></li>
                <li><span className="spec-k">Flow</span><span className="spec-v num">Laminar (volume-based)</span></li>
                <li><span className="spec-k">Stroke Volume</span><span className="spec-v num">0–160 mL · 0.2 mL step</span></li>
                <li><span className="spec-k">MAP</span><span className="spec-v num">3–40 cm H₂O</span></li>
                <li><span className="spec-k">Frequency</span><span className="spec-v num">5–17 Hz</span></li>
                <li><span className="spec-k">Patients</span><span className="spec-v num">500 g → children</span></li>
                <li><span className="spec-k">Auto-readings</span><span className="spec-v num">ΔA · MAP · V_hfo · DCO₂</span></li>
              </ul>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}

/* ---------- 10. CHEAT SHEET ---------- */
function CheatSheet() {
  return (
    <section className="block block-final" data-screen-label="10 Summary">
      <SectionLabel n="14" label="Cheat sheet · Keep it next to the device" />
      <h2 className="block-title">
        HFO in <span className="accent">12 lines.</span>
      </h2>

      <div className="cheat-grid">
        <div className="cheat-card"><div className="cheat-icon">🪽</div><div className="cheat-text"><b>HFO = hummingbird.</b> Small fast oscillations instead of big breaths.</div></div>
        <div className="cheat-card"><div className="cheat-icon">⚖️</div><div className="cheat-text"><b>Piston vs JET.</b> Humming Vue is volume-based (assured). JET is pressure-based (volume "floats," watch the trigger).</div></div>
        <div className="cheat-card"><div className="cheat-icon">🎈</div><div className="cheat-text"><b>Lungs stay open all the time.</b> No inflate-deflate. Held on MAP.</div></div>
        <div className="cheat-card"><div className="cheat-icon">🎯</div><div className="cheat-text"><b>4 settings on the right:</b> SV · MAP · f · FiO₂.</div></div>
        <div className="cheat-card"><div className="cheat-icon">📊</div><div className="cheat-text"><b>4 auto-readings on the left:</b> ΔA · measured MAP · V<sub>hfo</sub> · DCO₂. Judge the work by these.</div></div>
        <div className="cheat-card"><div className="cheat-icon">🧮</div><div className="cheat-text"><b>DCO₂ = V<sub>hfo</sub>² × f.</b> The exact number you assess the process by.</div></div>
        <div className="cheat-card"><div className="cheat-icon">🫁</div><div className="cheat-text"><b>SpO₂ → MAP and FiO₂.</b> MAP matters more: find the "opening point."</div></div>
        <div className="cheat-card"><div className="cheat-icon">💨</div><div className="cheat-text"><b>CO₂ → SV (main) and f.</b> SV forms V<sub>hfo</sub>. Step 0.2 mL.</div></div>
        <div className="cheat-card"><div className="cheat-icon">⚠️</div><div className="cheat-text"><b>ΔA ↑ + V<sub>hfo</sub>/DCO₂ → 0</b> = ETT blocked → suction immediately.</div></div>
        <div className="cheat-card"><div className="cheat-icon">⏱</div><div className="cheat-text"><b>Blood gas at 20–30 min.</b> Not sooner, not later.</div></div>
        <div className="cheat-card"><div className="cheat-icon">📉</div><div className="cheat-text"><b>Weaning:</b> FiO₂ first by 5%, then MAP by 1 cm. Never the other way.</div></div>
        <div className="cheat-card"><div className="cheat-icon">📡</div><div className="cheat-text"><b>Flow sensor = certainty.</b> With it you see real V<sub>hfo</sub> and DCO₂. Without it — blood gas + eye + ΔA.</div></div>
      </div>

      <div className="footer-bar">
        <div className="footer-brand">
          <img src={(typeof window !== 'undefined' && window.__resources && window.__resources.logoWordmark) || "assets/logo-wordmark.svg"} alt="Swanston-Med"/>
        </div>
        <div className="footer-meta">
          <span>Humming Vue · HFO · Bundle C — Neonatal</span>
          <span className="dot">·</span>
          <span>Tashkent · 2026</span>
          <span className="dot">·</span>
          <span>swanston.uz</span>
        </div>
      </div>
    </section>
  );
}

/* Export to window for cross-script access */
Object.assign(window, {
  SectionLabel, Tag,
  Hero, WaveformCompare, Metaphor, Indications,
  HowToStart, AdjustmentMatrix, Mistakes, DeviceAnatomy, CheatSheet,
});
