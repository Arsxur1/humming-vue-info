# Swanston-Med Design System

> Medical products distributor · Tashkent, Uzbekistan · founded 2026
> _"Когда каждая секунда имеет значение"_ — When every second matters.

---

## Company context

**Swanston-Med LLC** is a B2B medical-equipment and consumables distributor operating in Uzbekistan. Their portfolio is ~12 product lines from international manufacturers (Fengao dressings, Amoul i6 Defib, E6 CPR compressor, KellyMed infusion pumps, Humming ventilators, GIULIA NIV, ZOLL defibrillators, Konted wireless USG, Nutrisens enteral nutrition, Lingze ENFit feeding systems, Gentherm, Penlon Prima MRI, Novlead iNO, etc.) sold into ICUs, NICUs, emergency services, private clinics and state hospitals.

**Market:** Tashkent-first, then regional Uzbekistan. Year-1 revenue target $80–200K across 10+ active clients and 5 UZFDA registrations.

**Contact & public handles**
- Address — Katta Darkhan St. 25, Tashkent
- Phone — +998 78 150-23-76 · Email — info@swanston.uz · Web — swanston.uz
- Telegram `@swanston_med` · Instagram `@swanston.med` · LinkedIn `Swanston Med LLC`

**Communication languages:** Russian (primary — all source material is RU), Uzbek (expected), English (for international partners / LinkedIn).

**Audience / tone:** written for executives, clinical decision-makers (Head of ICU, chief neonatologist, medical directors, procurement leads) and KOL doctors. Internally this deck is a sales/marketing playbook — confident, technical, numbers-first.

---

## Source material

| File | What it is |
|---|---|
| `uploads/Swanston_Med_Visual_Charts_RU.pptx` | 20-slide Russian-language strategic deck: priority matrices, bubble map, heat-map, sales funnel, 12-month timeline, Gantt, channel map, competitor radar, KPI dashboard, revenue forecast, risk matrix, product bundles, customer map, social plan, 8-week checklist, KOL pyramid, competitor comparison, budget, summary, contact slide |

No logo files, images or media were embedded in the deck — every visual is drawn from CSS shapes, type and a small set of emoji accents. This design system reconstructs the brand's visual language from the deck's typography, color usage, and layout motifs.

---

## Products represented (product taxonomy)

Bundled into 6 go-to-market groups:

- **BUNDLE A — Resuscitation:** Amoul i6 Defib · E6 CPR · ZOLL (premium) → ICU · ER · EMS
- **BUNDLE B — Consumables:** Fengao Dressings · Lingze ENFit kits · KellyMed consumables → all ICUs (monthly contracts)
- **BUNDLE C — Neonatal:** Humming Vue HFO · GIULIA NIV · Novlead iNO → NICU · Perinatal centers
- **BUNDLE D — OR / Surgery:** Gentherm · Keewell · Penlon Prima MRI → Operating rooms
- **BUNDLE E — Nutrition & care:** Nutrisens formulas · Lingze pump · KellyMed dual-channel → ICU · Neurology · Rehab
- **BUNDLE F — Diagnostics + IVL:** Konted wireless USG · KellyMed infusion · Origin Panther → small clinics · EMS · district hospitals

---

## Index — what's in this folder

| Path | Purpose |
|---|---|
| `README.md` | This file — brand, content, visual & iconography guide |
| `SKILL.md` | Skill manifest for use in Claude Code |
| `colors_and_type.css` | CSS variables for colors, type and spacing tokens |
| `fonts/` | Web fonts (Inter Tight + JetBrains Mono — see notes) |
| `assets/` | Logo recreations, marketing glyphs, icons |
| `preview/` | Design-system cards (shown in the Design System tab) |
| `ui_kits/website/` | Swanston-Med marketing site UI kit (React/JSX) |
| `slides/` | 16:9 slide templates matching the source deck |

---

## CONTENT FUNDAMENTALS

**Language & register.** Primary language is **Russian**; technical acronyms stay in Latin (ICU → ОРИТ, NICU → ОРИТН, KPI, CPR, EtCO₂, UZFDA, KOL, ENFit, HFO). **Uzbek transliteration** is reserved for place-names and government bodies (`UzMedExpo`, `TIHE`, `UNGM`). English only appears in product names (Fengao, Konted, ZOLL) and on LinkedIn.

**Voice.** Direct, confident, numeric. The brand speaks like a trusted senior sales operator briefing a doctor — it presumes clinical literacy, drops jargon without apology, and leads with specifics: money, dates, counts, efficiency deltas.

**Casing.**
- Headlines and section titles — **ALL-CAPS**, short, always with a spaced dot separator when layered (`МАТРИЦА ПРИОРИТЕТОВ — 12 ПРОДУКТОВ`, `Эффективность · Стоимость · Срок`).
- Sub-headlines — **sentence case**, no period.
- Body — **sentence case**.
- Product names — **preserve manufacturer casing** (`Fengao`, `KellyMed`, `ZOLL`, `Amoul i6`).

**Punctuation marks that recur.**
- Middot `·` as a list separator (`Priority · Speed · Budget`).
- Em dash `—` introducing a category (`Fengao — FDA+CE+ISO, −35% vs 3M`).
- Right arrow `→` for flow and cause-effect (`Образцы → ОРИТ`, `СТОИМОСТЬ →`).
- Up arrow `↑` for axis labels (`ПОТЕНЦИАЛ ↑`, `ЭФФЕКТИВНОСТЬ ↑`).
- Multiplication sign `×` in titles (`ПРОДУКТ × ТИП КЛИЕНТА`).
- Typographic minus `−` for discounts (`−35%`, `−50%`).
- Ampersand-free — use "и" / "and" explicitly.

**Numbers.**
- Currency: `$8K`, `$80–200K`, `$5,000`. Always USD. No `USD` suffix.
- Percentages: `95%`, `−50–70%`.
- Ranges: en-dash (`5–12`, `3–6 мес.`). Non-breaking space between value and unit is preferred in body copy.
- Dates: short RU forms (`Апр`, `Нед. 5–6`, `Мес. 2–4`).

**I/you.** The brand is plural "мы" (we) internally but speaks in imperative form externally: `Зарегистрироваться на стенд немедленно.` / `Создать канал сегодня.` — bullet-point command tense when instructing, declarative when claiming.

**Vibe.**
- Military-op playbook meets investor deck. "Операция «Ташкент-2026»."
- Positive pressure, not hype. Urgency comes from dates (`24 часа`, `48 часов`), not exclamation marks.
- Zero marketing fluff. No "revolutionary," no "game-changing," no "best-in-class" — facts carry the weight (`FDA+CE+ISO`, `90% Japanese components`, `4-in-1`, `5.8 kg`).
- Clinical credibility > polish. The deck flexes specs and certifications, not adjectives.

**Examples to preserve:**
- ✅ `Fengao — FDA+CE+ISO, −35% vs 3M`
- ✅ `70% сил — ПОСЛЕ продажи. Довольный клиент = 5 новых без рекламы.`
- ✅ `Продаём системами, не устройствами` (slogan for bundles)
- ✅ `Глубоко, не широко.` — focus mantra
- ✅ `Когда каждая секунда имеет значение` — tagline

**Emoji.** Yes, used sparingly and with intent. The deck uses section-marker emoji (🎯 focus, ⚡ urgency, 🏆 strength, 💰 money, 📅 dates, 💬 Telegram, 🤝 service, 📊 targets) as color-coded glyphs on summary slides, plus social platform marks (💬 📸 ▶ 💼) and a small status vocabulary (🔥 high, 🟡 medium, 🔵 low, ⬜ none, ✓ done). **Do not freestyle** — stick to this set.

---

## VISUAL FOUNDATIONS

### Palette (extracted from deck usage)

The deck runs on a **deep-navy + teal** primary, **amber** for warning/emphasis, and a **full slate neutral scale** for chart backgrounds and table rules. Status colors are a saturated Tailwind-style palette (red / amber / green / blue / cyan / purple).

| Role | Hex | Use |
|---|---|---|
| `navy-900` | `#0A1628` | Primary bg on dark/title slides, headlines |
| `navy-800` | `#1E3A5F` | Secondary dark fill |
| `teal-600` | `#0D9488` | Primary accent, KPI, CTA |
| `teal-500` | `#14B8A6` | Hover / lighter accent |
| `amber-500` | `#F59E0B` | Warning, "urgent," priority markers |
| `slate-50` | `#F8FAFC` | Card / chart canvas |
| `slate-100` | `#F1F5F9` | Alt row, rule |
| `slate-200` | `#E2E8F0` | Border, divider |
| `slate-300` | `#CBD5E1` | Muted rule |
| `slate-500` | `#64748B` | Secondary text |
| `slate-700` | `#334155` | Body text |
| Status: red `#EF4444` / `#DC2626` · amber `#F59E0B` / `#92400E` · green `#16A34A` / `#166534` · blue `#3B82F6` / `#1E40AF` · cyan `#0891B2` · purple `#7C3AED` · pink `#E1306C` · linkedin `#0A66C2` |

**Color rules.**
- No gradients anywhere in the source — **avoid** them. Solid fills only.
- Pair navy + teal for hierarchy; amber earns its place on ~1 item per view.
- Status colors live in chart cells and chips; do not use them for primary UI chrome.
- Tinted backgrounds (`#DCFCE7`, `#FEF3C7`, `#DBEAFE`, `#FEF2F2`) appear as cell-fill shades in the heat-map — reserve them for data viz, not page backgrounds.

### Typography

The source PPTX uses **Calibri** (Microsoft default). For web/HTML this system substitutes **Inter Tight** (display + UI) and **JetBrains Mono** (tabular numbers and code). Both are Google Fonts. **⚠️ Substitution flagged** — if the brand adopts a licensed face later (Suisse, Söhne, Graphik, etc.), swap `--font-sans` in `colors_and_type.css`.

- **Display / H1** — Inter Tight 800, tight tracking (`-0.02em`), ALL CAPS for titles.
- **H2** — Inter Tight 700, sentence case.
- **H3** — Inter Tight 600.
- **Body** — Inter Tight 400 / 500.
- **Overline / eyebrow** — Inter Tight 600, `0.12em` letter-spacing, ALL CAPS, `13px`.
- **Tabular numbers** — JetBrains Mono 500 for KPIs, budgets, prices.
- **Cyrillic is first-class** — all faces chosen support Cyrillic.

### Spacing & layout

- **Base unit — 4px**, scale: 4 · 8 · 12 · 16 · 24 · 32 · 48 · 64.
- **Slide canvas** — 1920×1080, inner safe margin 72px.
- **Content rhythm** — strong top eyebrow (16–24px), large title (56–96px), generous whitespace above body, tight table grids below.
- **Grid** — 12-col on web, 24-col on slides for chart-dense layouts.

### Backgrounds

- **No photographic imagery in the source.** The brand is chart-forward, not photo-forward.
- **Predominant page bg** is off-white `--slate-50`. Title and section-opener slides flip to solid `--navy-900`.
- **No gradients**, no hand-drawn illustrations, no textures, no patterns.
- **Full-bleed** is reserved for the opening and closing slides of the deck.

### Animation

- Source is static PowerPoint — **no motion precedent**. Default posture: **subtle and quick**.
- Transitions — fade/slide at `180–220ms`, easing `cubic-bezier(0.2, 0.8, 0.2, 1)`.
- No bounces, no springs, no parallax.

### Interactive states

- **Hover** — shift fill one step darker (`teal-600` → `teal-700`), or raise shadow one level on cards.
- **Press** — `scale(0.98)` + a tighter shadow. No color flash.
- **Focus** — 2px teal ring offset 2px — `box-shadow: 0 0 0 2px #F8FAFC, 0 0 0 4px #0D9488`.
- **Disabled** — 40% opacity, no cursor change beyond `not-allowed`.

### Borders, radii, shadows

- **Border** — `1px solid var(--slate-200)` default, `--slate-300` on emphasis.
- **Radii** — `4px` (chip, input), `8px` (button, small card), `12px` (card), `16px` (large surface), `9999px` (pill). Slides themselves are square corners.
- **Shadow system** (elevation):
  - `shadow-1` — `0 1px 2px rgba(10,22,40,0.06)` — resting
  - `shadow-2` — `0 4px 12px rgba(10,22,40,0.08)` — hover
  - `shadow-3` — `0 12px 32px rgba(10,22,40,0.12)` — dialog / overlay
  - No inner shadows. No colored/glow shadows.

### Cards

- White `--slate-50` surface, `1px` slate-200 border, `12px` radius, `shadow-1`.
- Elevated variant — no border, `shadow-2`.
- **Status cards** — a solid colored corner tab or a 4px top border in the status color (`amber-500` for warning, `teal-600` for info, `red-500` for risk). No full-left-border-only accent.
- Bundle cards (slide 12) — navy header band with the bundle letter, slate-50 body.

### Transparency & blur

- Used sparingly. Overlay scrims on hero navy at 80% opacity. No frosted/blurred glass effects.

### Imagery treatment

- When photography is added (recommended for website), filter toward **cool, clinical, high-contrast**. Neutral skin tones, clean hospital whites, no warm/sepia casts. Black & white acceptable for KOL portraits.

### Chart & data-viz posture

- Tables are the backbone. Bold header row on navy, alternating `slate-50` / `white` rows, 1px slate-200 rules.
- Heat-maps use the tint palette (DCFCE7 / FEF3C7 / DBEAFE / FEF2F2) with the saturated equivalent as the cell type.
- Axes are labeled in all-caps eyebrow style with trailing `→` / `↑`.
- Every chart in the source has a title line + a subtitle line — keep this dual-title pattern.

---

## ICONOGRAPHY

**The source deck has no icon set.** Every visual mark is one of:
1. **Emoji glyphs** — used as section markers (🎯 ⚡ 🏆 💰 📅 💬 🤝 📊), status markers (🔥 high, 🟡 medium, 🔵 low, ⬜ empty, ✓ done), and platform marks (💬 Telegram, 📸 Instagram, ▶ YouTube, 💼 LinkedIn).
2. **Unicode arrows & symbols** — `→ ↑ ↓ ·  —  × ± ≥ ℃ ©`.
3. **Typography as icon** — letter-in-circle (`Bundle A`, `Bundle B`), number-in-circle (`1 2 3 4 5`), initials monograms.

**For the web/product surface**, Swanston-Med has no proprietary icon font, so this system **substitutes Lucide** (CDN-linked) as the working icon set. Lucide matches the brand posture: 2px stroke, rounded joins, square-ish geometry, zero decoration. **⚠️ Substitution flagged** — if you acquire a licensed clinical icon set later, swap `<i data-lucide>` calls in the UI kit.

**Rules.**
- Icon stroke weight — **2px**, `currentColor`. No filled-duotone mix.
- Icon sizes — `16 · 20 · 24 · 32`. Default `20`.
- **Never draw SVG freehand** for common icons — always link Lucide or copy the asset.
- Emoji are allowed in marketing copy and internal decks; **avoid** in product UI chrome (table headers, buttons, navigation).
- Unicode arrows (`→ ↑`) are preferred over drawn arrow icons for axis labels and flows.

**Logo.** No logo file was provided. This system reconstructs a **wordmark** (`SWANSTON-MED` in Inter Tight 800 all-caps, wide tracking, navy on white / white on navy) and a **cross-and-dot monogram** (medical cross in teal with an amber pulse dot) — both in `assets/`. **⚠️ Reconstruction flagged** — please provide the official logo if one exists.

---

## Index of registered design-system cards

Rendered in the Design System tab. See `preview/` for source.

- **Brand** — Logo (wordmark + monogram), tagline
- **Colors** — Primary (navy + teal), Accent (amber), Neutrals (slate), Status palette, Tint palette
- **Type** — Display scale, UI scale, Tabular numbers, Casing rules
- **Spacing** — Spacing scale, Radii, Shadow elevation
- **Components** — Buttons, Inputs, Cards, Tables, Chips, Status indicators, Bundle card, KPI card
- **Slides** — Title slide, Matrix slide, Heat-map, Funnel, Comparison table, Summary

---

## Caveats

- **No logo file** — wordmark and monogram are reconstructions, not official marks.
- **Calibri → Inter Tight** — font substitution pending brand confirmation.
- **No photography or illustration** — source was chart-only; website UI kit uses placeholders where photography would live.
- **No icon system** — substituted Lucide.
