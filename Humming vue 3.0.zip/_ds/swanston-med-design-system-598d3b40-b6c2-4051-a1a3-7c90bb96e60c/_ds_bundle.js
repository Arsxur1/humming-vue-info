/* @ds-bundle: {"format":3,"namespace":"SwanstonMedDesignSystem_598d3b","components":[],"sourceHashes":{"ui_kits/website/BundleGrid.jsx":"29b0a5d14ad7","ui_kits/website/ContactBlock.jsx":"b023f8a1d0b9","ui_kits/website/Footer.jsx":"edcbc5e1eeca","ui_kits/website/Hero.jsx":"5e1661a375d5","ui_kits/website/Nav.jsx":"b458f6df8a37","ui_kits/website/ProductCompare.jsx":"e54f9cda9711","ui_kits/website/StatStrip.jsx":"89437f015af0"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.SwanstonMedDesignSystem_598d3b = window.SwanstonMedDesignSystem_598d3b || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// ui_kits/website/BundleGrid.jsx
try { (() => {
function BundleGrid() {
  const bundles = [{
    l: 'A',
    t: 'Реанимация',
    items: ['Amoul i6 Defib', 'E6 CPR', 'ZOLL (премиум)'],
    tgt: 'ОРИТ · ER · СМП',
    color: 'var(--teal-600)'
  }, {
    l: 'B',
    t: 'Расходники',
    items: ['Fengao Dressings', 'Lingze ENFit', 'KellyMed расходники'],
    tgt: 'Все ОРИТ · месячный контракт',
    color: 'var(--amber-500)'
  }, {
    l: 'C',
    t: 'Новорождённые',
    items: ['Humming Vue ВЧО', 'GIULIA NIV', 'Novlead iNO'],
    tgt: 'ОРИТН · Перинат. центры',
    color: 'var(--teal-600)'
  }, {
    l: 'D',
    t: 'Операционная',
    items: ['Gentherm', 'Keewell', 'Penlon Prima MRI'],
    tgt: 'Операционные · Хирургия',
    color: 'var(--status-blue)'
  }, {
    l: 'E',
    t: 'Питание · уход',
    items: ['Nutrisens формулы', 'Lingze насос', 'KellyMed двойной'],
    tgt: 'ОРИТ · Неврология · Реабилитация',
    color: 'var(--status-purple)'
  }, {
    l: 'F',
    t: 'Диагностика + ИВЛ',
    items: ['Konted USG', 'KellyMed инфуз.', 'Origin Panther'],
    tgt: 'Малые клиники · СМП · Районные б-цы',
    color: 'var(--status-cyan)'
  }];
  return /*#__PURE__*/React.createElement("section", {
    id: "bundles",
    style: bgStyles.root
  }, /*#__PURE__*/React.createElement("div", {
    style: bgStyles.inner
  }, /*#__PURE__*/React.createElement("div", {
    style: bgStyles.eyebrow
  }, "\u0411\u0430\u043D\u0434\u043B-\u0441\u0442\u0440\u0430\u0442\u0435\u0433\u0438\u044F"), /*#__PURE__*/React.createElement("h2", {
    style: bgStyles.h2
  }, "\u041F\u0440\u043E\u0434\u0430\u0451\u043C \u0441\u0438\u0441\u0442\u0435\u043C\u0430\u043C\u0438, \u043D\u0435 \u0443\u0441\u0442\u0440\u043E\u0439\u0441\u0442\u0432\u0430\u043C\u0438"), /*#__PURE__*/React.createElement("p", {
    style: bgStyles.sub
  }, "6 \u0433\u043E\u0442\u043E\u0432\u044B\u0445 \u0441\u0432\u044F\u0437\u043E\u043A \u043F\u043E\u0434 \u043A\u043E\u043D\u043A\u0440\u0435\u0442\u043D\u044B\u0435 \u043E\u0442\u0434\u0435\u043B\u0435\u043D\u0438\u044F. \u041E\u0434\u0438\u043D \u043A\u043E\u043D\u0442\u0440\u0430\u043A\u0442, \u043E\u0434\u0438\u043D \u0441\u0435\u0440\u0432\u0438\u0441, \u043E\u0434\u0438\u043D \u043E\u0442\u0432\u0435\u0442\u0441\u0442\u0432\u0435\u043D\u043D\u044B\u0439."), /*#__PURE__*/React.createElement("div", {
    style: bgStyles.grid
  }, bundles.map(b => /*#__PURE__*/React.createElement("div", {
    key: b.l,
    style: bgStyles.card
  }, /*#__PURE__*/React.createElement("div", {
    style: bgStyles.hd
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      ...bgStyles.letter,
      background: b.color,
      color: b.l === 'B' ? 'var(--navy-900)' : '#fff'
    }
  }, b.l), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: bgStyles.bl
  }, "\u0411\u0430\u043D\u0434\u043B ", b.l), /*#__PURE__*/React.createElement("div", {
    style: bgStyles.bt
  }, b.t))), /*#__PURE__*/React.createElement("div", {
    style: bgStyles.body
  }, b.items.map(x => /*#__PURE__*/React.createElement("div", {
    key: x,
    style: bgStyles.item
  }, x))), /*#__PURE__*/React.createElement("div", {
    style: bgStyles.ft
  }, "\uD83D\uDC65 ", b.tgt))))));
}
const bgStyles = {
  root: {
    background: 'var(--slate-50)',
    padding: '80px 48px'
  },
  inner: {
    maxWidth: 1100,
    margin: '0 auto'
  },
  eyebrow: {
    fontSize: 12,
    letterSpacing: '0.2em',
    textTransform: 'uppercase',
    color: 'var(--teal-600)',
    fontWeight: 700
  },
  h2: {
    fontSize: 40,
    fontWeight: 800,
    letterSpacing: '-0.02em',
    margin: '6px 0 10px',
    textTransform: 'uppercase',
    color: 'var(--navy-900)'
  },
  sub: {
    fontSize: 16,
    color: 'var(--fg3)',
    margin: '0 0 32px',
    maxWidth: 720
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(3,1fr)',
    gap: 16
  },
  card: {
    background: '#fff',
    border: '1px solid var(--border)',
    borderRadius: 12,
    overflow: 'hidden',
    boxShadow: '0 1px 2px rgba(10,22,40,0.06)'
  },
  hd: {
    background: 'var(--navy-900)',
    color: '#fff',
    padding: '14px 16px',
    display: 'flex',
    alignItems: 'center',
    gap: 12
  },
  letter: {
    width: 40,
    height: 40,
    borderRadius: 8,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontWeight: 800,
    fontSize: 20
  },
  bl: {
    fontSize: 10,
    letterSpacing: '0.14em',
    textTransform: 'uppercase',
    color: '#94A3B8',
    fontWeight: 700
  },
  bt: {
    fontSize: 16,
    fontWeight: 700
  },
  body: {
    padding: '12px 16px'
  },
  item: {
    padding: '7px 0',
    fontSize: 13,
    color: 'var(--fg2)',
    borderBottom: '1px solid var(--rule)'
  },
  ft: {
    padding: '10px 16px',
    background: 'var(--slate-50)',
    borderTop: '1px solid var(--border)',
    fontSize: 12,
    color: 'var(--fg3)'
  }
};
Object.assign(window, {
  BundleGrid
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/BundleGrid.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ContactBlock.jsx
try { (() => {
function ContactBlock() {
  const [submitted, setSubmitted] = React.useState(false);
  return /*#__PURE__*/React.createElement("section", {
    id: "contact",
    style: cbStyles.root
  }, /*#__PURE__*/React.createElement("div", {
    style: cbStyles.inner
  }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
    style: cbStyles.eyebrow
  }, "\u0421\u043B\u0435\u0434\u0443\u044E\u0449\u0438\u0439 \u0448\u0430\u0433"), /*#__PURE__*/React.createElement("h2", {
    style: cbStyles.h2
  }, "\u0414\u0435\u043C\u043E \u0437\u0430 24 \u0447\u0430\u0441\u0430.", /*#__PURE__*/React.createElement("br", null), "\u041E\u0431\u0440\u0430\u0437\u0446\u044B \u0437\u0430 48."), /*#__PURE__*/React.createElement("p", {
    style: cbStyles.sub
  }, "\u0420\u0430\u0441\u0441\u043A\u0430\u0436\u0438\u0442\u0435 \u043E\u0431 \u043E\u0442\u0434\u0435\u043B\u0435\u043D\u0438\u0438 \u2014 \u043C\u044B \u043F\u043E\u0434\u0431\u0435\u0440\u0451\u043C \u0431\u0430\u043D\u0434\u043B, \u043F\u0440\u0438\u0432\u0435\u0437\u0451\u043C \u0434\u0435\u043C\u043E-\u0435\u0434\u0438\u043D\u0438\u0446\u0443 \u0438 \u043E\u0431\u0440\u0430\u0437\u0446\u044B, \u043E\u0442\u043F\u0440\u0430\u0432\u0438\u043C \u041A\u041F \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 \u0441\u0443\u0442\u043E\u043A."), /*#__PURE__*/React.createElement("div", {
    style: cbStyles.info
  }, /*#__PURE__*/React.createElement("div", {
    style: cbStyles.infoRow
  }, /*#__PURE__*/React.createElement("span", {
    style: cbStyles.infoL
  }, "\u0422\u0435\u043B\u0435\u0444\u043E\u043D"), /*#__PURE__*/React.createElement("span", null, "+998 78 150-23-76")), /*#__PURE__*/React.createElement("div", {
    style: cbStyles.infoRow
  }, /*#__PURE__*/React.createElement("span", {
    style: cbStyles.infoL
  }, "E-mail"), /*#__PURE__*/React.createElement("span", null, "info@swanston.uz")), /*#__PURE__*/React.createElement("div", {
    style: cbStyles.infoRow
  }, /*#__PURE__*/React.createElement("span", {
    style: cbStyles.infoL
  }, "\u0410\u0434\u0440\u0435\u0441"), /*#__PURE__*/React.createElement("span", null, "Katta Darkhan St. 25, Tashkent")), /*#__PURE__*/React.createElement("div", {
    style: cbStyles.infoRow
  }, /*#__PURE__*/React.createElement("span", {
    style: cbStyles.infoL
  }, "Telegram"), /*#__PURE__*/React.createElement("span", null, "@swanston_med")))), /*#__PURE__*/React.createElement("form", {
    style: cbStyles.form,
    onSubmit: e => {
      e.preventDefault();
      setSubmitted(true);
    }
  }, submitted ? /*#__PURE__*/React.createElement("div", {
    style: cbStyles.done
  }, /*#__PURE__*/React.createElement("div", {
    style: cbStyles.doneIco
  }, "\u2713"), /*#__PURE__*/React.createElement("div", {
    style: cbStyles.doneT
  }, "\u0417\u0430\u044F\u0432\u043A\u0430 \u043F\u0440\u0438\u043D\u044F\u0442\u0430"), /*#__PURE__*/React.createElement("div", {
    style: cbStyles.doneS
  }, "\u0421\u0432\u044F\u0436\u0435\u043C\u0441\u044F \u0432 \u0442\u0435\u0447\u0435\u043D\u0438\u0435 24 \u0447\u0430\u0441\u043E\u0432. \u0421\u0440\u0435\u0434\u043D\u0438\u0439 \u0441\u0440\u043E\u043A \u041A\u041F \u2014 18 \u0447.")) : /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("div", {
    style: cbStyles.field
  }, /*#__PURE__*/React.createElement("label", {
    style: cbStyles.label
  }, "\u0424\u0418\u041E"), /*#__PURE__*/React.createElement("input", {
    style: cbStyles.input,
    placeholder: "\u0418\u0432\u0430\u043D\u043E\u0432 \u0418\u0432\u0430\u043D"
  })), /*#__PURE__*/React.createElement("div", {
    style: cbStyles.field
  }, /*#__PURE__*/React.createElement("label", {
    style: cbStyles.label
  }, "\u041A\u043B\u0438\u043D\u0438\u043A\u0430 / \u0411\u043E\u043B\u044C\u043D\u0438\u0446\u0430"), /*#__PURE__*/React.createElement("input", {
    style: cbStyles.input,
    placeholder: "\u041D\u0430\u0437\u0432\u0430\u043D\u0438\u0435 \u043E\u0440\u0433\u0430\u043D\u0438\u0437\u0430\u0446\u0438\u0438"
  })), /*#__PURE__*/React.createElement("div", {
    style: cbStyles.field
  }, /*#__PURE__*/React.createElement("label", {
    style: cbStyles.label
  }, "\u0422\u0435\u043B\u0435\u0444\u043E\u043D"), /*#__PURE__*/React.createElement("input", {
    style: cbStyles.input,
    placeholder: "+998 __ ___-__-__"
  })), /*#__PURE__*/React.createElement("div", {
    style: cbStyles.field
  }, /*#__PURE__*/React.createElement("label", {
    style: cbStyles.label
  }, "\u0427\u0442\u043E \u0438\u043D\u0442\u0435\u0440\u0435\u0441\u0443\u0435\u0442"), /*#__PURE__*/React.createElement("select", {
    style: cbStyles.input
  }, /*#__PURE__*/React.createElement("option", null, "\u0411\u0430\u043D\u0434\u043B A \xB7 \u0420\u0435\u0430\u043D\u0438\u043C\u0430\u0446\u0438\u044F"), /*#__PURE__*/React.createElement("option", null, "\u0411\u0430\u043D\u0434\u043B B \xB7 \u0420\u0430\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u0438"), /*#__PURE__*/React.createElement("option", null, "\u0411\u0430\u043D\u0434\u043B C \xB7 \u041D\u043E\u0432\u043E\u0440\u043E\u0436\u0434\u0451\u043D\u043D\u044B\u0435"), /*#__PURE__*/React.createElement("option", null, "\u041E\u0442\u0434\u0435\u043B\u044C\u043D\u044B\u0439 \u043F\u0440\u043E\u0434\u0443\u043A\u0442"))), /*#__PURE__*/React.createElement("button", {
    type: "submit",
    style: cbStyles.submit
  }, "\u0417\u0430\u043A\u0430\u0437\u0430\u0442\u044C \u0434\u0435\u043C\u043E \u2192"), /*#__PURE__*/React.createElement("div", {
    style: cbStyles.fine
  }, "\u0421\u043E\u0433\u043B\u0430\u0441\u0435\u043D \u043D\u0430 \u0441\u0432\u044F\u0437\u044C \u043F\u043E WhatsApp / Telegram. \u0414\u0430\u043D\u043D\u044B\u0435 \u043D\u0435 \u043F\u0435\u0440\u0435\u0434\u0430\u044E\u0442\u0441\u044F \u0442\u0440\u0435\u0442\u044C\u0438\u043C \u043B\u0438\u0446\u0430\u043C.")))));
}
const cbStyles = {
  root: {
    background: 'var(--navy-900)',
    color: '#fff',
    padding: '80px 48px'
  },
  inner: {
    maxWidth: 1100,
    margin: '0 auto',
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: 48
  },
  eyebrow: {
    fontSize: 12,
    letterSpacing: '0.2em',
    textTransform: 'uppercase',
    color: 'var(--teal-500)',
    fontWeight: 700
  },
  h2: {
    fontSize: 44,
    fontWeight: 800,
    letterSpacing: '-0.02em',
    margin: '8px 0 16px',
    textTransform: 'uppercase',
    lineHeight: 1,
    color: '#fff'
  },
  sub: {
    fontSize: 16,
    color: '#CBD5E1',
    lineHeight: 1.55,
    maxWidth: 440,
    margin: '0 0 28px'
  },
  info: {
    borderTop: '1px solid rgba(255,255,255,0.1)'
  },
  infoRow: {
    display: 'flex',
    justifyContent: 'space-between',
    padding: '14px 0',
    borderBottom: '1px solid rgba(255,255,255,0.1)',
    fontSize: 14
  },
  infoL: {
    color: '#64748B',
    letterSpacing: '0.1em',
    textTransform: 'uppercase',
    fontWeight: 600,
    fontSize: 12
  },
  form: {
    background: '#fff',
    borderRadius: 12,
    padding: 24,
    color: 'var(--navy-900)',
    boxShadow: '0 12px 32px rgba(0,0,0,0.3)'
  },
  field: {
    display: 'flex',
    flexDirection: 'column',
    gap: 6,
    marginBottom: 14
  },
  label: {
    fontSize: 12,
    fontWeight: 600,
    color: 'var(--fg2)',
    letterSpacing: '0.02em'
  },
  input: {
    fontFamily: 'var(--font-sans)',
    fontSize: 14,
    padding: '11px 12px',
    border: '1px solid var(--border-strong)',
    borderRadius: 8,
    background: '#fff',
    color: 'var(--fg1)',
    outline: 'none'
  },
  submit: {
    background: 'var(--teal-600)',
    color: '#fff',
    padding: '14px 16px',
    borderRadius: 8,
    fontWeight: 700,
    fontSize: 15,
    border: 0,
    cursor: 'pointer',
    width: '100%',
    marginTop: 6
  },
  fine: {
    fontSize: 11,
    color: 'var(--fg3)',
    marginTop: 12,
    lineHeight: 1.4
  },
  done: {
    textAlign: 'center',
    padding: '40px 20px'
  },
  doneIco: {
    width: 56,
    height: 56,
    borderRadius: '50%',
    background: 'var(--status-green)',
    color: '#fff',
    fontSize: 28,
    fontWeight: 800,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    margin: '0 auto 16px'
  },
  doneT: {
    fontSize: 22,
    fontWeight: 800,
    color: 'var(--navy-900)',
    letterSpacing: '-0.01em'
  },
  doneS: {
    fontSize: 14,
    color: 'var(--fg3)',
    marginTop: 8
  }
};
Object.assign(window, {
  ContactBlock
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ContactBlock.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Footer.jsx
try { (() => {
function Footer() {
  return /*#__PURE__*/React.createElement("footer", {
    style: footStyles.root
  }, /*#__PURE__*/React.createElement("div", {
    style: footStyles.inner
  }, /*#__PURE__*/React.createElement("div", {
    style: footStyles.brand
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/monogram-light.svg",
    alt: "",
    width: "32",
    height: "32"
  }), /*#__PURE__*/React.createElement("span", {
    style: footStyles.wm
  }, "SWANSTON-MED")), /*#__PURE__*/React.createElement("div", {
    style: footStyles.links
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: footStyles.a
  }, "\u041F\u0440\u043E\u0434\u0443\u043A\u0442\u044B"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: footStyles.a
  }, "\u0411\u0430\u043D\u0434\u043B\u044B"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: footStyles.a
  }, "\u041A\u043E\u043D\u0442\u0430\u043A\u0442\u044B"), /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: footStyles.a
  }, "UZFDA")), /*#__PURE__*/React.createElement("div", {
    style: footStyles.social
  }, /*#__PURE__*/React.createElement("span", {
    style: {
      ...footStyles.s,
      background: '#26A5E4'
    }
  }, "\uD83D\uDCAC"), /*#__PURE__*/React.createElement("span", {
    style: {
      ...footStyles.s,
      background: '#E1306C'
    }
  }, "\uD83D\uDCF8"), /*#__PURE__*/React.createElement("span", {
    style: {
      ...footStyles.s,
      background: '#FF0000'
    }
  }, "\u25B6"), /*#__PURE__*/React.createElement("span", {
    style: {
      ...footStyles.s,
      background: '#0A66C2'
    }
  }, "\uD83D\uDCBC")), /*#__PURE__*/React.createElement("div", {
    style: footStyles.copy
  }, "\xA9 Swanston-Med LLC, 2026 \xB7 Katta Darkhan St. 25, Tashkent")));
}
const footStyles = {
  root: {
    background: '#0F172A',
    color: '#94A3B8',
    padding: '40px 48px'
  },
  inner: {
    maxWidth: 1100,
    margin: '0 auto',
    display: 'grid',
    gridTemplateColumns: '1fr 1fr auto',
    gap: 32,
    alignItems: 'center'
  },
  brand: {
    display: 'flex',
    alignItems: 'center',
    gap: 10
  },
  wm: {
    color: '#fff',
    fontWeight: 800,
    fontSize: 16,
    letterSpacing: '0.03em'
  },
  links: {
    display: 'flex',
    gap: 22,
    justifyContent: 'center'
  },
  a: {
    color: '#94A3B8',
    textDecoration: 'none',
    fontSize: 13,
    fontWeight: 500
  },
  social: {
    display: 'flex',
    gap: 8
  },
  s: {
    width: 32,
    height: 32,
    borderRadius: 8,
    color: '#fff',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    fontSize: 15
  },
  copy: {
    gridColumn: '1 / -1',
    borderTop: '1px solid rgba(255,255,255,0.08)',
    paddingTop: 18,
    fontSize: 12,
    color: '#64748B',
    letterSpacing: '0.04em'
  }
};
Object.assign(window, {
  Footer
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Footer.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Hero.jsx
try { (() => {
function Hero() {
  return /*#__PURE__*/React.createElement("section", {
    style: heroStyles.root
  }, /*#__PURE__*/React.createElement("div", {
    style: heroStyles.grid
  }), /*#__PURE__*/React.createElement("div", {
    style: heroStyles.inner
  }, /*#__PURE__*/React.createElement("div", {
    style: heroStyles.eyebrow
  }, "\u0422\u0430\u0448\u043A\u0435\u043D\u0442 \xB7 Uzbekistan \xB7 \u0441 2026"), /*#__PURE__*/React.createElement("h1", {
    style: heroStyles.h1
  }, "\u041A\u043E\u0433\u0434\u0430 \u043A\u0430\u0436\u0434\u0430\u044F", /*#__PURE__*/React.createElement("br", null), "\u0441\u0435\u043A\u0443\u043D\u0434\u0430 ", /*#__PURE__*/React.createElement("span", {
    style: heroStyles.accent
  }, "\u0438\u043C\u0435\u0435\u0442 \u0437\u043D\u0430\u0447\u0435\u043D\u0438\u0435.")), /*#__PURE__*/React.createElement("p", {
    style: heroStyles.sub
  }, "\u041E\u0444\u0438\u0446\u0438\u0430\u043B\u044C\u043D\u044B\u0439 \u0434\u0438\u0441\u0442\u0440\u0438\u0431\u044C\u044E\u0442\u043E\u0440 \u043C\u0435\u0434\u0438\u0446\u0438\u043D\u0441\u043A\u043E\u0433\u043E \u043E\u0431\u043E\u0440\u0443\u0434\u043E\u0432\u0430\u043D\u0438\u044F \u0438 \u0440\u0430\u0441\u0445\u043E\u0434\u043D\u0438\u043A\u043E\u0432.", /*#__PURE__*/React.createElement("br", null), "12 \u043F\u0440\u043E\u0434\u0443\u043A\u0442\u043E\u0432\u044B\u0445 \u043B\u0438\u043D\u0435\u0435\u043A \xB7 FDA + CE + ISO \xB7 \u0441\u0435\u0440\u0432\u0438\u0441 \u0432 \u0422\u0430\u0448\u043A\u0435\u043D\u0442\u0435."), /*#__PURE__*/React.createElement("div", {
    style: heroStyles.row
  }, /*#__PURE__*/React.createElement("a", {
    href: "#contact",
    style: heroStyles.primary
  }, "\u0417\u0430\u043A\u0430\u0437\u0430\u0442\u044C \u0434\u0435\u043C\u043E \u2014 24 \u0447"), /*#__PURE__*/React.createElement("a", {
    href: "#bundles",
    style: heroStyles.ghost
  }, "\u041F\u043E\u0441\u043C\u043E\u0442\u0440\u0435\u0442\u044C \u043F\u043E\u0440\u0442\u0444\u0435\u043B\u044C")), /*#__PURE__*/React.createElement("div", {
    style: heroStyles.rule
  }), /*#__PURE__*/React.createElement("div", {
    style: heroStyles.badges
  }, /*#__PURE__*/React.createElement("span", null, "FDA"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "CE"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "ISO 13485"), /*#__PURE__*/React.createElement("span", null, "\xB7"), /*#__PURE__*/React.createElement("span", null, "UZFDA registered"))));
}
const heroStyles = {
  root: {
    position: 'relative',
    background: 'var(--navy-900)',
    color: '#fff',
    padding: '88px 48px 96px',
    overflow: 'hidden'
  },
  grid: {
    position: 'absolute',
    inset: 0,
    backgroundImage: 'linear-gradient(rgba(255,255,255,.03) 1px,transparent 1px),linear-gradient(90deg,rgba(255,255,255,.03) 1px,transparent 1px)',
    backgroundSize: '60px 60px'
  },
  inner: {
    position: 'relative',
    maxWidth: 1100,
    margin: '0 auto'
  },
  eyebrow: {
    fontSize: 13,
    letterSpacing: '0.2em',
    textTransform: 'uppercase',
    color: 'var(--teal-500)',
    fontWeight: 700,
    marginBottom: 22
  },
  h1: {
    fontSize: 76,
    fontWeight: 800,
    letterSpacing: '-0.02em',
    lineHeight: 0.98,
    margin: 0,
    textTransform: 'uppercase',
    color: '#fff'
  },
  accent: {
    color: 'var(--teal-500)'
  },
  sub: {
    marginTop: 22,
    fontSize: 19,
    color: '#CBD5E1',
    lineHeight: 1.5,
    maxWidth: 760
  },
  row: {
    marginTop: 34,
    display: 'flex',
    gap: 12,
    flexWrap: 'wrap'
  },
  primary: {
    background: 'var(--teal-600)',
    color: '#fff',
    padding: '14px 22px',
    borderRadius: 10,
    fontWeight: 700,
    fontSize: 15,
    textDecoration: 'none'
  },
  ghost: {
    background: 'transparent',
    color: '#fff',
    padding: '14px 22px',
    borderRadius: 10,
    fontWeight: 600,
    fontSize: 15,
    textDecoration: 'none',
    border: '1px solid rgba(255,255,255,0.25)'
  },
  rule: {
    height: 4,
    width: 120,
    background: 'var(--amber-500)',
    marginTop: 44
  },
  badges: {
    marginTop: 22,
    display: 'flex',
    gap: 10,
    fontSize: 12,
    color: '#94A3B8',
    letterSpacing: '0.15em',
    textTransform: 'uppercase',
    fontWeight: 600
  }
};
Object.assign(window, {
  Hero
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Hero.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/Nav.jsx
try { (() => {
function Nav() {
  const items = ['Продукты', 'Бандлы', 'Клиентам', 'О нас', 'Контакты'];
  return /*#__PURE__*/React.createElement("nav", {
    style: navStyles.root
  }, /*#__PURE__*/React.createElement("a", {
    href: "#",
    style: navStyles.brand
  }, /*#__PURE__*/React.createElement("img", {
    src: "../../assets/monogram.svg",
    alt: "Swanston-Med",
    width: "36",
    height: "36"
  }), /*#__PURE__*/React.createElement("span", {
    style: navStyles.word
  }, "SWANSTON-MED")), /*#__PURE__*/React.createElement("div", {
    style: navStyles.links
  }, items.map(x => /*#__PURE__*/React.createElement("a", {
    key: x,
    href: "#",
    style: navStyles.link
  }, x))), /*#__PURE__*/React.createElement("div", {
    style: navStyles.right
  }, /*#__PURE__*/React.createElement("button", {
    style: navStyles.lang
  }, "RU"), /*#__PURE__*/React.createElement("a", {
    href: "#contact",
    style: navStyles.cta
  }, "\u0417\u0430\u043A\u0430\u0437\u0430\u0442\u044C \u0434\u0435\u043C\u043E \u2192")));
}
const navStyles = {
  root: {
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'space-between',
    padding: '18px 48px',
    borderBottom: '1px solid var(--border)',
    background: '#fff',
    position: 'sticky',
    top: 0,
    zIndex: 10
  },
  brand: {
    display: 'flex',
    alignItems: 'center',
    gap: 12,
    textDecoration: 'none',
    color: 'var(--navy-900)'
  },
  word: {
    fontWeight: 800,
    fontSize: 18,
    letterSpacing: '0.03em'
  },
  links: {
    display: 'flex',
    gap: 28
  },
  link: {
    fontSize: 14,
    fontWeight: 500,
    color: 'var(--fg2)',
    textDecoration: 'none'
  },
  right: {
    display: 'flex',
    alignItems: 'center',
    gap: 12
  },
  lang: {
    border: '1px solid var(--border-strong)',
    background: '#fff',
    borderRadius: 6,
    padding: '6px 10px',
    fontWeight: 600,
    fontSize: 12,
    cursor: 'pointer',
    color: 'var(--fg1)'
  },
  cta: {
    background: 'var(--teal-600)',
    color: '#fff',
    padding: '10px 16px',
    borderRadius: 8,
    fontWeight: 600,
    fontSize: 14,
    textDecoration: 'none'
  }
};
Object.assign(window, {
  Nav
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/Nav.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/ProductCompare.jsx
try { (() => {
function ProductCompare() {
  const rows = [{
    cat: 'Повязки',
    us: 'Fengao — FDA+CE+ISO',
    them: '3M Tegaderm',
    edge: '−35% по цене'
  }, {
    cat: 'Авто-СЛР',
    us: 'E6 CPR — EtCO₂ встроен',
    them: 'LUCAS 3',
    edge: 'В 3–4× дешевле'
  }, {
    cat: 'Дефибрилляция',
    us: 'Amoul i6 — 4-в-1, 5.8 кг',
    them: 'Schiller · Philips',
    edge: '4 функции в 1'
  }, {
    cat: 'Инф. насосы',
    us: 'KellyMed — 30 лет, CE',
    them: 'B. Braun Space',
    edge: '−50–70%'
  }, {
    cat: 'Беспр. УЗИ',
    us: 'Konted — Wi-Fi + AI',
    them: 'Mindray стационар',
    edge: 'Мобильность + AI'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: pcStyles.root
  }, /*#__PURE__*/React.createElement("div", {
    style: pcStyles.inner
  }, /*#__PURE__*/React.createElement("div", {
    style: pcStyles.eyebrow
  }, "\u0421\u0440\u0430\u0432\u043D\u0435\u043D\u0438\u0435"), /*#__PURE__*/React.createElement("h2", {
    style: pcStyles.h2
  }, "Swanston-Med vs \u043A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442\u044B"), /*#__PURE__*/React.createElement("p", {
    style: pcStyles.sub
  }, "\u0413\u0434\u0435 \u043C\u044B \u043E\u0431\u044A\u0435\u043A\u0442\u0438\u0432\u043D\u043E \u0432\u044B\u0438\u0433\u0440\u044B\u0432\u0430\u0435\u043C \u2014 \u043F\u043E \u0446\u0435\u043D\u0435, \u043F\u043E \u0441\u043F\u0435\u0446\u0438\u0444\u0438\u043A\u0430\u0446\u0438\u044F\u043C, \u043F\u043E \u0441\u0440\u043E\u043A\u0430\u043C \u043F\u043E\u0441\u0442\u0430\u0432\u043A\u0438."), /*#__PURE__*/React.createElement("div", {
    style: pcStyles.table
  }, /*#__PURE__*/React.createElement("div", {
    style: pcStyles.head
  }, /*#__PURE__*/React.createElement("div", null, "\u041A\u0430\u0442\u0435\u0433\u043E\u0440\u0438\u044F"), /*#__PURE__*/React.createElement("div", {
    style: {
      color: '#fff',
      background: 'var(--teal-600)',
      padding: '8px 12px',
      margin: '-10px -12px',
      borderRadius: 4
    }
  }, "Swanston-Med"), /*#__PURE__*/React.createElement("div", null, "\u041A\u043E\u043D\u043A\u0443\u0440\u0435\u043D\u0442"), /*#__PURE__*/React.createElement("div", null, "\u041F\u0440\u0435\u0438\u043C\u0443\u0449\u0435\u0441\u0442\u0432\u043E")), rows.map((r, i) => /*#__PURE__*/React.createElement("div", {
    key: r.cat,
    style: {
      ...pcStyles.row,
      background: i % 2 ? 'var(--slate-50)' : '#fff'
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: pcStyles.cat
  }, r.cat), /*#__PURE__*/React.createElement("div", {
    style: pcStyles.us
  }, r.us), /*#__PURE__*/React.createElement("div", {
    style: pcStyles.them
  }, r.them), /*#__PURE__*/React.createElement("div", {
    style: pcStyles.edge
  }, r.edge))))));
}
const pcStyles = {
  root: {
    padding: '80px 48px',
    background: '#fff'
  },
  inner: {
    maxWidth: 1100,
    margin: '0 auto'
  },
  eyebrow: {
    fontSize: 12,
    letterSpacing: '0.2em',
    textTransform: 'uppercase',
    color: 'var(--teal-600)',
    fontWeight: 700
  },
  h2: {
    fontSize: 40,
    fontWeight: 800,
    letterSpacing: '-0.02em',
    margin: '6px 0 10px',
    textTransform: 'uppercase',
    color: 'var(--navy-900)'
  },
  sub: {
    fontSize: 16,
    color: 'var(--fg3)',
    margin: '0 0 32px',
    maxWidth: 720
  },
  table: {
    border: '1px solid var(--border)',
    borderRadius: 12,
    overflow: 'hidden'
  },
  head: {
    display: 'grid',
    gridTemplateColumns: '18% 32% 26% 24%',
    gap: 0,
    background: 'var(--navy-900)',
    color: '#fff',
    padding: '14px 16px',
    fontSize: 11,
    letterSpacing: '0.12em',
    textTransform: 'uppercase',
    fontWeight: 700
  },
  row: {
    display: 'grid',
    gridTemplateColumns: '18% 32% 26% 24%',
    gap: 0,
    padding: '14px 16px',
    fontSize: 14,
    borderTop: '1px solid var(--rule)'
  },
  cat: {
    fontWeight: 700,
    color: 'var(--navy-900)'
  },
  us: {
    color: 'var(--navy-900)',
    fontWeight: 600
  },
  them: {
    color: 'var(--fg3)'
  },
  edge: {
    color: 'var(--teal-700)',
    fontWeight: 700,
    fontSize: 13
  }
};
Object.assign(window, {
  ProductCompare
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/ProductCompare.jsx", error: String((e && e.message) || e) }); }

// ui_kits/website/StatStrip.jsx
try { (() => {
function StatStrip() {
  const stats = [{
    n: '12',
    l: 'продуктовых линеек'
  }, {
    n: '6',
    l: 'бандлов под отделения'
  }, {
    n: 'FDA+CE+ISO',
    l: 'сертификации'
  }, {
    n: '24 ч',
    l: 'коммерч. предложение'
  }, {
    n: '48 ч',
    l: 'образцы на руки'
  }];
  return /*#__PURE__*/React.createElement("section", {
    style: statStyles.root
  }, /*#__PURE__*/React.createElement("div", {
    style: statStyles.inner
  }, stats.map((s, i) => /*#__PURE__*/React.createElement("div", {
    key: i,
    style: statStyles.item
  }, /*#__PURE__*/React.createElement("div", {
    style: statStyles.n
  }, s.n), /*#__PURE__*/React.createElement("div", {
    style: statStyles.l
  }, s.l)))));
}
const statStyles = {
  root: {
    background: '#fff',
    borderBottom: '1px solid var(--border)',
    padding: '28px 48px'
  },
  inner: {
    maxWidth: 1100,
    margin: '0 auto',
    display: 'grid',
    gridTemplateColumns: 'repeat(5,1fr)',
    gap: 24
  },
  item: {
    borderLeft: '3px solid var(--teal-600)',
    paddingLeft: 14
  },
  n: {
    fontFamily: 'var(--font-mono)',
    fontWeight: 600,
    fontSize: 30,
    color: 'var(--navy-900)',
    letterSpacing: '-0.02em',
    lineHeight: 1
  },
  l: {
    fontSize: 12,
    color: 'var(--fg3)',
    letterSpacing: '0.08em',
    textTransform: 'uppercase',
    fontWeight: 600,
    marginTop: 6
  }
};
Object.assign(window, {
  StatStrip
});
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/website/StatStrip.jsx", error: String((e && e.message) || e) }); }

})();
